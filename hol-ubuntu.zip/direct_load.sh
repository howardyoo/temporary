#!/bin/bash

if [ $# -ne 3 ] ; then
   echo "this script requires 3 arguments: data_file, base_url, api_token"
   exit 1
fi

while IFS='' read -r line || [[ -n "$line" ]]; do
   echo "sending data: $line to https://$2.wavefront.com/report?f=graphite_v2"
   echo "$line" | curl -H "Authorization: Bearer $3" --data @- https://$2.wavefront.com/report?f=graphite_v2
   sleep 5
done < "$1"

